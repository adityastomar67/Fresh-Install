#!/usr/bin/env bash
set -e

./build-deploy.sh
./deploy-github.sh